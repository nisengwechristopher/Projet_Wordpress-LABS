
/**
 * Actions to take place when the page loads.
 * the dark page drops and is removed
 * the main message colors change.
 * the first section size gets smaller and the section container gets smaller as well.
 * add a right border to the first div
 * the icons  / side bar comes up.
 * animation on page load
 */

setTimeout( () => {

    var drop, introSection, introContent, sideBar, wrapper, footer;

    drop = document.querySelector('.drop').style;
    introContent = document.querySelector('.intro-content h1').style;
    introSection = document.querySelector('#welocme-section').style;
    sideBar = document.querySelector('.sidebar').style;
    wrapper = document.querySelector('.wrapper').style;
    footer = document.querySelector('footer').style;


    /** this div passes down through the page on load */
    drop.position = 'absolute';
    drop.top = '100vh';
    drop.transition = 'all ease 1.2s';

    /** styling on the welcome message */
    introContent.color = '#171313';
    introContent.transition = 'all ease-in 1s';

    /**
     * Changes to take place after 1.5 seconds after the pages loades ..
     * in order to happen after the .drop div "passes"
     * */
    setTimeout( ()=> {
        /** changin the size and adding a border to the welcome section */
        introSection.borderRight = '1px solid #2c2b2b';
        introSection.width = '80vw';
        introSection.transition = 'all ease-out 1s';


        /** hides the dropping page after the page loads */
        drop.display = 'none';
        wrapper.width = '380vw';


        /**showing the side bar icons and the name / site logo */
        setTimeout(() => {
            sideBar.marginTop = '80vh';
            sideBar.transition = 'all ease 1s';

            // /** showes the footer */
            // footer.bottom = '0px';
            // footer.transition = 'all ease-out 1s';
        }, 700);

    }, 1000);

}, 500);










/**
 *
 * ON LOAD MAKE THE HAMBURGER MENU ANIMATE
 */

var menuAnimation = () => {

}

document.querySelector('.menu-hamburger');


setTimeout(() => {
    change();
}, 5000);


var change = () => {
    var letters = document.querySelector('.first-col-elem');
    for (let i = 0; i < letters.childElementCount; i++) {
        var letter = letters.children[i];
        letter.classList.add('active');
        console.log(letter);
    };
}